#!/bin/bash 
# === Validacion de ayuda ===
if [["$1" == "-help" || "$1" == "--help"||"$#" -ne 2 ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
fi
ORIGEN="$1"
DESTINO="$2"
# === Validacion de existencia de origen y destino ===
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen 'ORIGEN' no existe."
	exit 2
fi 
if [[! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de destino 'DESTINO' no existe."
	exit 3
fi
# === Formato de fecha: YYYYMMDD ===
FECHA=$(date +%Y%m%d)
# === Nombre del archivo de backup ===
NOMBRE_BKP=$(basename "$ORIGEN")_bkp_"$FECHA".tar.gz
# === Crear backup ===
tar -czf "$DESTINO/$NOMBRE_BKP" "$ORIGEN"
# === Resultado ===
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $DESTINO/$NOMBRE_BKP"
else 
    echo "Error durante el backup."
    exit 4
fi










